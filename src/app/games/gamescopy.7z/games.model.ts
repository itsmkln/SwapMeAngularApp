export class GamesModel {
    GameId: number = 0;
    Name: string = "";
    GenreId: number = 0;
    Image?: HTMLImageElement;
}